/* global google */

import { useContext, useState, useEffect } from "react";
import styles from "./Translate.module.css";

export const Translate = (props) => {
    return <></>;
};
